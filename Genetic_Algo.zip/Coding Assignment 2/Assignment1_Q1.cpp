#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<cmath>
#include<ctime>
#include<fstream>
using namespace std;
double decode(double xmin,double xmax,int l,int x[]);
double fitness(double r1,double r2);
int main()
{
	int n=2,l=5,N=1024,i,j;									//Sub string length = 5, No of solution in solution Space=1024
	double decodex1[N],decodex2[N],fv[N],fvt,p[N],cp[N];
	int iteration_max=400,iteration=1,pos;
	int P[N][l*n],Pdash[N][l*n];
	double C[N][l*n];
	int s[N][l*n],x1[l],x2[l],X1[N][l],X2[N][l];
	int MS[N],rn,sum,rn1;
	double pc=1;
	double xmin=0,xmax=0.5;
	for(i=0;i<N;i++)
	{
		MS[i]=i+1;
	}
	double RN1,RN2;
	srand(time(0));
	for(i=0;i<N;i++)
	{
		for(j=0;j<(l*n);j++)
		{
			s[i][j]=rand()%2;
		}
	}
	while(iteration<=iteration_max)
	{
		fvt=0;
		for(i=0;i<N;i++)
		{
			for(j=0;j<l;j++)
			{
				x1[j]=s[i][j];
				X1[i][j]=s[i][j];
			}
			for(j=l;j<(n*l);j++)
			{
				x2[j-l]=s[i][j];
				X2[i][j-l]=s[i][j];
			}
			decodex1[i]=decode(xmin,xmax,l,x1);
			decodex2[i]=decode(xmin,xmax,l,x2);
			fv[i]=fitness(decodex1[i],decodex2[i]);
			fvt=fvt+fv[i];	
		}
		
		for(i=0;i<N;i++)
		{
			p[i]=fv[i]/fvt;
		}
		
		cp[0]=p[0];
		for(i=1;i<N;i++)
		{
			cp[i]=cp[i-1]+p[i];
		}
		
		for(i=0;i<N;i++)
		{
			RN1=(double)(rand()%11)/10;
			for(j=0;j<N;j++)
			{
				if(RN1<=cp[j])
				{
					pos=j;
					goto label1;
				}
			}
			label1:
			for(j=0;j<(l*n);j++)
			{
				P[i][j]=s[pos][j];
			}
		}
		
		sum=0;
		MS[0]=rand()%N;
		sum=MS[0];
		for(i=1;i<(N-1);i++)
		{
			label :
			rn=rand()%N;
			for(j=0;j<i;j++)
			{
				if(rn==MS[j])
				{
					goto label;	
				}
			}
			MS[i]=rn;
			sum=sum+MS[i];
		}
		MS[N-1]=N*(N-1)/2-sum;
		for(i=0;i<N;i++)
		{
			for(j=0;j<(l*n);j++)
			{
				Pdash[i][j]=P[MS[i]][j];
			}
		}
		for(i=0;i<N;i=i+2)
		{
			RN2=(double)(rand()%11)/10;
			if(RN2<=pc)
			{
				rn1=rand()%5;
				for(j=0;j<(l*n);j++)
				{
					if(j<=rn1)
					{
						C[i][j]=Pdash[i][j];
						C[i+1][j]=Pdash[i+1][j];
					}
					else
					{
						C[i][j]=Pdash[i+1][j];
						C[i+1][j]=Pdash[i][j];
					}
				}
			}
		}
		for(i=0;i<N;i++)
		{
			for(j=0;j<(l*n);j++)
			{
				s[i][j]=C[i][j];
			}
		}
		
		iteration++;
	}
	for(i=0;i<N;i++)
	{
		decodex1[i]=decode(xmin,xmax,l,X1[i]);
		decodex2[i]=decode(xmin,xmax,l,X2[i]);
	}
	ofstream o;
	o.open("output.txt");
	o<<"The optimum X1 and X2 values found out to be :\n";
	o<<decodex1[0]<<" "<<decodex2[0];
	return 0;
}
double decode(double xmin,double xmax,int l,int x[])
{
	int k=0;
	double decoded_value=0;
	for(k=0;k<l;k++)
	{
		decoded_value=decoded_value+(double)(x[k]*pow(2,l-k-1));
	}
	return (xmin+(xmax-xmin)/(pow(2,l)-1)*(decoded_value));
}
double fitness(double r1,double r2)
{
	return (1/(1+pow((r1+r2-2*r1*r1-r2*r2*+r1*r2),2)));
}
